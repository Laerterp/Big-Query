CREATE TABLE dim_customers (
  customer_sk INTEGER AUTOINCREMENT PRIMARY KEY,
  customer_id INTEGER NOT NULL UNIQUE,
  customer_name VARCHAR(50) NOT NULL,
  email VARCHAR(50) UNIQUE,
  address VARCHAR(100)
);

CREATE TABLE dim_products (
  product_sk INTEGER AUTOINCREMENT PRIMARY KEY,
  product_id INTEGER NOT NULL UNIQUE,
  product_name VARCHAR(50) NOT NULL,
  description VARCHAR(500),
  price DECIMAL(10,2) NOT NULL
);

CREATE TABLE dim_dates (
  date_sk INTEGER AUTOINCREMENT PRIMARY KEY,
  date DATE NOT NULL UNIQUE,
  day INTEGER NOT NULL,
  month INTEGER NOT NULL,
  year INTEGER NOT NULL,
  quarter INTEGER NOT NULL
);

CREATE TABLE fact_sales (
  sale_sk INTEGER AUTOINCREMENT PRIMARY KEY,	
  sale_id INTEGER,
  customer_sk INTEGER NOT NULL,
  product_sk INTEGER NOT NULL,
  date_sk INTEGER NOT NULL,
  quantity INTEGER NOT NULL,
  FOREIGN KEY (customer_sk) REFERENCES dim_customers(customer_sk),
  FOREIGN KEY (product_sk) REFERENCES dim_products(product_sk),
  FOREIGN KEY (date_sk) REFERENCES dim_dates(date_sk)
);


INSERT  INTO DIM_DATES ( DATE,DAY,MONTH, YEAR, QUARTER)
WITH date_range AS (
  SELECT
    DATEADD(day, ROW_NUMBER() OVER (ORDER BY seq4()) - 1, '2020-01-01') AS date
  FROM
    TABLE(GENERATOR(rowcount => 2191)) -- 2191 days between '2020-01-01' and '2025-12-31'
),
date_components AS (
  SELECT
    date,
    EXTRACT(day FROM date) AS day,
    EXTRACT(month FROM date) AS month,
    EXTRACT(year FROM date) AS year,
    EXTRACT(quarter FROM date) AS quarter
  FROM
    date_range
)
SELECT  date,day,month, year, quarter FROM  date_components

